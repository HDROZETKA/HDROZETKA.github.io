import requests as r
import os
import zipfile

try:
    from main import main
except ImportError:
    pass

URL = 'http://HDROZETKA.github.io'

CURRRENT_VERSION = '1.0.0.0.0.0.1'

try:
    global response
    response = r.get(URL)
except r.ConnectionError:
    print('Интернет отсуствует')

html = response.text
version = html.split()[13]

if version == CURRRENT_VERSION:
    main.run()
else:
    url_down = URL +  '/main.zip'
    a = os.getcwd()
    b = a.replace('main', '')
    os.chdir(b)
    file = open('tmp_files.zip', "wb")
    response = r.get(url_down)
    file.write(response.content)
    file.close()
    fantasy_zip = zipfile.ZipFile('tmp_files.zip')
    fantasy_zip.extractall('')
    fantasy_zip.close()
    os.remove(b)
    print('Успешно установленно обновление')
    print('Запустите start.py еще раз')


os.system('timeout 20')