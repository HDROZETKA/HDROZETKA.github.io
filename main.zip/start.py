import requests as r
import os
import zipfile
import time

URL = 'http://HDROZETKA.github.io'

CURRRENT_VERSION = '1.0.0.0.0.0.1'

def downloadNewVersion():
    url_down = URL + '/main.zip'
    a = os.getcwd()
    b = a.replace('main', '')
    os.chdir(b)
    file = open('tmp_files.zip', "wb")
    response = r.get(url_down)
    file.write(response.content)
    file.close()
    fantasy_zip = zipfile.ZipFile('tmp_files.zip')
    fantasy_zip.extractall('')
    fantasy_zip.close()
    complexCheck()
    print('Успешно установленно обновление')
    print('Запустите start.py еще раз')

def complexCheck():
    try:
        global response
        response = r.get(URL)
    except r.ConnectionError:
        print('Подключение к Интернету отсуствует')



    try:
        from main import queries
        from main import websites
        from main import main
        result = 1
    except ImportError:
        result = 0
        downloadNewVersion()
    if not(result == 1):
        err = 'Ошибка файлов, скачиваю...'
        print(err)
        complexCheck()



    html = response.text
    version = html.split()[13]
    if version == CURRRENT_VERSION:
        main.run()
    else:
        err = 'Ошибка версии, скачиваю...'
        print(err)
        downloadNewVersion()

print('Это окно будет закрыто через 10 секунд.')
time.sleep(10)