import requests as r
import os
import zipfile
import time

URL = 'http://HDROZETKA.github.io'

CURRRENT_VERSION = '1.0.0.0.0.0.1'

FILES = ('queries', 'websites', 'code')

def downloadNewVersion():
    url_down = URL + '/main.zip'
    a = os.getcwd()
    b = a.replace('main', '')
    os.chdir(b)
    file = open('tmp_files.zip', "wb")
    response = r.get(url_down)
    file.write(response.content)
    file.close()
    fantasy_zip = zipfile.ZipFile('tmp_files.zip')
    fantasy_zip.extractall('')
    fantasy_zip.close()
    print('Успешно установленно обновление')

def complexCheck():
    try:
        global response
        response = r.get(URL)
    except r.ConnectionError:
        print('Подключение к Интернету отсуствует')
        time.sleep(2)
        complexCheck()



    try:
        global result
        for file in FILES:
            exec('from main import {}'.format(file))
        result = 1
    except ImportError:
        result = 0
    if not(result == 1):
        err = 'Ошибка файлов, скачиваю...'
        print(err)
        downloadNewVersion()
        import start as start2
        start2.complexCheck()



    html = response.text
    version = html.split()[13]
    if not(version == CURRRENT_VERSION):
        err = 'Ошибка версии, скачиваю...'
        print(err)
        downloadNewVersion()
        import start as start2
        start2.complexCheck()

complexCheck()
from main import code
code.run()
print('Это окно будет закрыто через 10 секунд.')
time.sleep(10)