import requests as r
import os
from main import main
import zipfile

URL = 'http://HDROZETKA.github.io'

CURRRENT_VERSION = '1.0.0.0.0.0.0'

try:
    global response
    response = r.get(URL)
except r.ConnectionError:
    print('Интернет отсуствует')

html = response.text
version = html.split()[13]

if version == CURRRENT_VERSION:
    main.run()
else:
    url_down = URL +  '/main.exe'
    a = os.getcwd()
    b = a.replace('main', '')
    os.chdir(b)
    file = open('tmp_files.zip', "wb")
    response = r.get(url_down)
    file.write(response.content)
    file.close()
    fantasy_zip = zipfile.ZipFile('tmp_files.zip')
    fantasy_zip.extractall('')
    fantasy_zip.close()
    print('Успешно установленно обновление')
    print('Запустите start.py еще раз')


os.system('timeout 20')