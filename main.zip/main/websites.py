websites = {
    #'': '',
    'google': 'google.com',
    'youtube': 'youtube.com',
}