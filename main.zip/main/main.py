import speech_recognition as sr
import webbrowser
import pyttsx3
import requests as r
import time
import random
import os

a = os.getcwd()
if not(a.find('main') == -1):
	path_main = True
	b = a.replace('main', '')
	os.chdir(b)
	import queries as q
	import websites as ws
else:
	import queries as q
	import websites as ws

DEVELOP_MODE = False # MUTE WELCOME
VOICE_NAME = 'Microsoft Irina Desktop - Russian'

def say(words):
	print(words)
	tts.say(words)
	tts.runAndWait()

def voiceManager():
	global tts
	tts = pyttsx3.init()
	voices = tts.getProperty('voices')
	tts.setProperty('voice', 'ru')
	for voice in voices:
		if voice.name == VOICE_NAME:
			tts.setProperty('voice', voice.id)

def tryConnectToGoogle(a=0):
	try:
		r.get('http://google.com')
		result = 1
	except r.exceptions.ConnectionError:
		result = 0
	if not(result == 1):
		err = 'Нету подключения к Интернету'
		if a == 1:
			say(err)
		else:
			time.sleep(2)
			print(err)
		tryConnectToGoogle()
	return result

def tryToFindMicrophone(a=0):
	try:
		sr.Microphone(device_index=None)
		result = 1
	except OSError:
		result = 0
	if not(result == 1):
		err = 'Я не нашла микрофон, через который вы должны говорить мне команды'
		if a == 1:
			say(err)
		else:
			time.sleep(2)
			print(err)
		tryToFindMicrophone()
	return result

def complexTry(a=0):
	if a == 0:
		result = tryConnectToGoogle(1)
		if result == 0:
			say('Подключение востановлено!')
		result = tryToFindMicrophone(1)
		if result == 0:
			say('Микрофон найден, и подключен!')
	elif a == 1:
		result = tryConnectToGoogle(1)
		if result == 0:
			say('Подключение востановлено!')
	elif a ==  2:
		result = tryToFindMicrophone(1)
		if result == 0:
			say('Микрофон найден, и подключен!')

def formingWords(r, audio):
	complexTry()
	try:
		zadanie = r.recognize_google(audio, language="ru-RU").lower()
		print("Вы сказали: " + zadanie)
		return zadanie
	except sr.UnknownValueError:
		say('Я вас не поняла')

def openSite(site_name):
	complexTry(1)
	for website_name in ws.websites.keys():
		if site_name == website_name:
			url = 'http://www.' +  ws.websites[website_name]
			say('Уже открываю')
			webbrowser.open(url)

def calculate(zadanie_split):
	result = 5
	for element_id in range(len(zadanie_split) - 1):
		element = zadanie_split[element_id]
		if not(element == 'посчитай'):
			pass

	say(f'Результат: {result}')

def makeSomething(zadanie):
	if zadanie == None:
		zadanie = ''
	for query in q.queries.keys():
		if not(zadanie.find(query) == -1):
			if type(q.queries[query]).__name__ == 'list':
				count_responses = len(q.queries[query])
				qr = random.randint(1, count_responses)
				return q.queries[query][qr-1]
			elif type(q.queries[query]).__name__ == 'str':
				if not(zadanie.find('открой сайт') == -1):
					return f"{q.queries[query]}'{zadanie.split()[2]}')"
				elif not(zadanie.find('хватит') == -1):
					say('Пока, пока...')
				elif not(zadanie.find('посчитай') == -1):
					return f"{q.queries[query]}{zadanie.split()})"
				return q.queries[query]

def run():
	voiceManager()
	complexTry()
	if DEVELOP_MODE == False:
		say("Привет, меня зовут Жужа")
		say("Чем я могу помочь вам?")
	while True:
		print('Говорите')
		with sr.Microphone() as source:
			r = sr.Recognizer()
			r.pause_threshold = 1
			r.adjust_for_ambient_noise(source, duration=1)
			audio = r.listen(source)

			try:
				exec(makeSomething(formingWords(r, audio)))
			except TypeError:
				pass

if path_main == True:
	run()